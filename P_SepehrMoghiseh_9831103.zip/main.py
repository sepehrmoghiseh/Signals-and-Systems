import scipy.io.wavfile
import glob
import os
import numpy as np
from numpy import fft
import matplotlib.pyplot as plt


# power spectrum
def create_power_spectrum(file_name):
    sampling_rate, data = scipy.io.wavfile.read(file_name)

    sum_stereo = data.sum(axis=1) / 2
    freq_nq = len(sum_stereo) // 2
    power_spectrum = (abs(fft.fft(sum_stereo))[:freq_nq] / len(data) * 2) ** 2
    frequency = fft.fftfreq(len(data), 1 / sampling_rate)[:freq_nq]
    plt.plot(frequency, power_spectrum)
    plt.xlim(0, 600)

    plt.show()
    return (frequency, power_spectrum)


def freq_for_maximum_power(file_name):
    frequency, power_spectrum = create_power_spectrum(file_name)
    max = frequency[np.argmax(power_spectrum)]
    return (max)


def which(folder):
    list = []
    for filename in glob.glob(os.path.join(folder, '*.wav')):
        max = freq_for_maximum_power(filename)
        if (max) <= 180:
            list.append(filename + ": " + "man  /"+"value: "+str(max))
        else:
            list.append(filename + ": " + "woman  /"+"value: "+str(max))

    print(list)


which("voices")
