from scipy.io import wavfile
import matplotlib.pyplot as plt
from math import sqrt
import numpy as np
from numpy import random
from librosa import stft, istft


def spectral_subtraction(sampling_rate, noisy_signal, noise):
    fft_noisy_signal = (stft(noisy_signal))
    absolute_value_fft_noisy_signal = np.abs(fft_noisy_signal)

    fft_noise = stft(noise)
    absolute_value_fft_noise = np.abs(fft_noise)

    a = np.angle(fft_noisy_signal)
    b = np.exp(1.0j * a)

    average_fft_noise = np.mean(absolute_value_fft_noise, axis=1)

    denoisySignal = istft(
        (absolute_value_fft_noisy_signal - average_fft_noise.reshape((average_fft_noise.shape[0], 1))) * b)
    denoisySignal_type = denoisySignal.astype(np.int16)
    wavfile.write('Denoise_signal_15.wav', sampling_rate, denoisySignal_type)


def AWGN_noise(sampling_rate, data, SNR):
    Root_mean_Square_signal = sqrt(np.mean(data ** 2))
    Root_mean_Square_noise = sqrt(Root_mean_Square_signal ** 2 / (pow(10, SNR / 10)))
    noise = (random.normal(0, Root_mean_Square_noise, data.shape[0])).astype(np.float32)
    noisy_signal = np.add(data, noise)
    wavfile.write('noisy_signal_15.wav', sampling_rate, noisy_signal.astype(np.int16))
    return noisy_signal, noise


def craete_plot_signals(filename):
    sampling_rate, complete_data = wavfile.read(filename)
    data = complete_data.astype(np.float32)
    n = data.shape[0] / sampling_rate
    t = np.linspace(0, n, data.shape[0])
    plt.plot(t, data)
    plt.xlabel("t")
    plt.ylabel("signal_magnitude")
    plt.show()


sampling_rate, comlete_data = wavfile.read("Test.wav")
data = comlete_data.astype(np.float32)
noisy_signal, noise = AWGN_noise(sampling_rate, data, 15)
spectral_subtraction(sampling_rate, noisy_signal, noise)

craete_plot_signals('Test.wav')
craete_plot_signals('noisy_signal_15.wav')
craete_plot_signals('Denoise_signal_15.wav')
