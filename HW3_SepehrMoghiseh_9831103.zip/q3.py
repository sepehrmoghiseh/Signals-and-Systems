import matplotlib.pyplot as plt
import numpy as np

step = 0.001
t = np.arange(-6, 6, step)

def a(sig, k, T0):
    w0 = 2 * np.pi / T0
    x = sig * np.cos(k * w0 * t)
    return (2 / T0) * np.sum(x) * step

def b(sig, k, T0):
    w0 = 2 * np.pi / T0
    x = sig * np.sin(k * w0 * t)
    return (2 / T0) * np.sum(x) * step

def fourier(sig, c, T0):
    w0 = 2 * np.pi / T0
    y = np.zeros((len(t), ))
    y += a(sig, 0, T0) / 2
    for k in range(1, c + 1):
        y += a(sig, k, T0)* np.cos(k * w0 * t) + b(sig, k, T0) * np.sin(k * w0 *t)
    return y/2

x = np.heaviside(t, 1) + np.heaviside(-t-3, 1) +\
    np.heaviside(-t+3, 1) -1

fig, s = plt.subplots()
s.plot(t, x, 'pink', label="x(t)")
for c in range(0, 11):
    s.plot(t, fourier(x, c, 6), 'green', label = c)
s.legend()
s.grid()

plt.show()