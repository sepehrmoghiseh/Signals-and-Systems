import numpy as np
import math
import matplotlib.pyplot as plt

time= np.arange(-1 , 1 ,0.00001)

def create_signal(t):
  return np.cos(10*np.pi*t)


main_signal= create_signal(time)
plt.plot(time ,main_signal )

def sampling(sampling_rate , time , main_signal):

  sample_step= 1/sampling_rate
  sampling_time= np.arange(time[0] , time[-1] ,sample_step )
  sampling_signal=create_signal(sampling_time)
  return sampling_time, sampling_signal


timeAndsignal= sampling(4 , time , main_signal)

plt.plot(timeAndsignal[0] , timeAndsignal[1],"r.")
plt.plot(timeAndsignal[0] , timeAndsignal[1],"g")

