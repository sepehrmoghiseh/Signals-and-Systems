import numpy as np
import math
import matplotlib.pyplot as plt

time= np.arange(-1 , 1 ,0.00001)

def create_signal(t):
  return np.cos(30*np.pi*t)


main_signal= create_signal(time)

def sampling(sampling_rate , time , main_signal):

  sample_step= 1/sampling_rate
  sampling_time= np.arange(time[0] , time[-1] ,sample_step )
  sampling_signal=create_signal(sampling_time)
  return sampling_time, sampling_signal

fig , signals = plt.subplots(6)
timeAndsignal= sampling(20 , time , main_signal)
signals[0].plot(time ,main_signal )
signals[0].plot(timeAndsignal[0] , timeAndsignal[1],"g.")
signals[1].plot(timeAndsignal[0] , timeAndsignal[1],"r")

timeAndsignal= sampling(30 , time , main_signal)
signals[2].plot(time ,main_signal )
signals[2].plot(timeAndsignal[0] , timeAndsignal[1],"g.")
signals[3].plot(timeAndsignal[0] , timeAndsignal[1],"r")


timeAndsignal= sampling(40 , time , main_signal)
signals[4].plot(time ,main_signal )
signals[4].plot(timeAndsignal[0] , timeAndsignal[1],"g.")
signals[5].plot(timeAndsignal[0] , timeAndsignal[1],"r")