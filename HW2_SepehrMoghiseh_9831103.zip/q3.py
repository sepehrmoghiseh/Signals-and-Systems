import numpy as np
import matplotlib.pyplot as plt


def ufunc(n, n0):
    unit = []
    for sample in n:
        if sample < n0:
            unit.append(0)
        else:
            unit.append(1)
    return (unit)


end1 = 20
start1 = -10
x1 = np.linspace(start1, end1, 31)

unit1 = ufunc(x1, 5)
unit2 = ufunc(x1, 0)

h1 = []
for i in range(31):
    h1.append((0.9) ** (x1[i]) * (unit1[i] - unit2[i]))

plt.stem(x1, h1)

plt.show()

unit3 = ufunc(x1, 0)
unit4 = ufunc(x1, 10)

y2 = []
for i in range(31):
    y2.append((1 / 3) ** (x1[i]) * (unit3[i] - unit4[i]))

plt.stem(x1, y2)

plt.show()


def convolve(x, h):
    n = len(x)
    y = np.zeros(2 * n)
    h = h[::-1]
    for i in range(n):
        y[i] = np.sum(h[n - i - 1:] * x[:i + 1])
        y[n + i] = np.sum(h[:n - i - 1] * x[i + 1:])

    return y[:2 * n - 1]


n = np.arange(-10, 20)
x2 = 0.9 ** n * (np.heaviside(n - 5, 1) + np.heaviside(n, 1))
h2 = 0.33 ** n * (np.heaviside(n, 1) + np.heaviside(n - 10, 1))
y3 = convolve(x2, h2)

t = np.arange(-20, 39, 1)
plt.stem(t, y3)

plt.show()
