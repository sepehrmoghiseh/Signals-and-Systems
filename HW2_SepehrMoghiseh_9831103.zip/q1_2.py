import numpy as np
import matplotlib.pyplot as plt


def ufunc(n, n0):
    unit = []
    for sample in n:
        if sample < n0:
            unit.append(0)
        elif sample > n0:
            unit.append(1)
    return (unit)


stop1 = 20
start1 = -10
step = 0.01
x1 = np.arange(start1, stop1, step)
unit1 = ufunc(x1, +10)
unit2 = ufunc(x1, 0)

y1 = []
for i in range(x1.size):
    y1.append(unit1[i] - unit2[i])

plt.plot(x1, y1)

plt.show()

# 2


stop2 = 0
start2 = -10
x2_1 = np.arange(start2, stop2, step)

y2_1 = []
for i in range(x2_1.size):
    y2_1.append(i - i)

stop3 = 5
start3 = 0
x2_2 = np.arange(start3, stop3, step)

y2_2 = []
for i in range(x2_2.size):
    y2_2.append(i)

stop4 = 10
start4 = 5
x2_3 = np.arange(start4, stop4, step)

y2_3 = []
for i in range(x2_3.size):
    y2_3.append(5 - i)

stop5 = 20
start5 = 10
x2_4 = np.arange(start5, stop5, step)

y2_4 = []
for i in range(x2_4.size):
    y2_4.append(i - i)

plt.plot(x2_1, y2_1)
plt.plot(x2_2, y2_2)
plt.plot(x2_3, y2_3)
plt.plot(x2_4, y2_4)

plt.show()


def convolve(x, h):
    n = len(x)
    y = np.zeros(2 * n)
    h = h[::-1]
    for i in range(n):
        y[i] = np.sum(h[n - i - 1:] * x[:i + 1])
        y[n + i] = np.sum(h[:n - i - 1] * x[i + 1:])
    return y[:2 * n - 1]


y2_0 = []

y2_0 = np.concatenate((y2_1, y2_2, y2_3, y2_4))

y3 = []
y3 = convolve(y1, y2_0)
t = np.arange(-20, 39.99, 0.01)

plt.plot(t, y3)
plt.show()
