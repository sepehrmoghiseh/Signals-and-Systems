import matplotlib.pyplot as plt
import numpy as np

# q1
x1 = np.arange(-1 * np.pi, np.pi, 0.01)  # start,stop,step
y1 = np.sin(x1)

plt.plot(x1, y1)
plt.show()
# <=============================================>
# q2
n = [*range(-5, 6, 1)]
y2 = []


def x2(i):
    if i < 0:
        j = (-1 * i) - 1
    else:
        j = i * i
    return j


for i in n:
    y2.append(x2(i))
plt.stem(n, y2)
plt.show()

# <=========================================================>

# q5
x5 = np.arange(-10, 11)  # start,stop,step
y5 = np.cos(3 * x5)
plt.stem(x5, y5)
plt.show()
# <=============================>
# q6
x6 = np.arange(-10, 11)  # start,stop,step
y6 = np.cos(3 * np.pi * x6)
plt.stem(x6, y6)
plt.show()
# <====================================>
# q8
y7 = np.sin(2 * x1 - 3)
plt.plot(2 * x1 - 3, y7)
plt.show()
# <===========================================>
# q10
y8 = np.sin(-1 * x1 + 3)
plt.plot(-1 * x1 + 3, y8)
plt.show()
