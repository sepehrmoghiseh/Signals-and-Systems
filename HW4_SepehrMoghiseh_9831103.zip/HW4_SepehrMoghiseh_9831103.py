import matplotlib.pyplot as plt
import scipy.integrate as integrate
import numpy as np

t = np.arange(-15, 15, 0.05)


def x1(t):
    return - np.heaviside(t - 1, 1) - np.heaviside(-t - 1, 1) + 1


def x2(t):
    return np.sinc(t) / np.pi


def x3(t):
    return (np.cos(t) * np.sin(3 * t)) / (np.pi * t)


def x4(t):
    return x2(t) ** 2


def x_ft(t, x, w):
    return (x(t) * np.exp(-1j * w * t)).real


def plot_s(x):
    fig, ax = plt.subplots(2)
    ax[0].plot(t, x(t))
    ft = [integrate.quad(x_ft, -15, 15, args=(x, w)) for w in t]
    ax[1].plot(t, ft)
    plt.show()


plot_s(x1)
plot_s(x2)
plot_s(x3)
plot_s(x4)
